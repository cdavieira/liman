#ifndef _compactador
#define _compactador

typedef struct mapa mapa;

mapa* ler_arquivo(char* nome);

#endif