#ifndef _tree_lib
#define _tree_lib

#define left 0
#define right 1

typedef struct tree tree;

/* Inicialização e finalização*/

tree* criar_arvore_nula();

tree* criar_arvore_alocada_default();

tree* criar_arvore_alocada_custom(void** item, tree** sad, tree** sae);

tree* liberar_arvore_alocada(tree* arvore, void* (*desalocar_item)());

/* Acesso aos campos do tipo estruturado tree*/


void** pegar_item_arvore(tree* arvore);

tree** pegar_no_esquerdo(tree* arvore);

tree** pegar_no_direito(tree* arvore);

tree** pegar_no(tree* arvore, int codigo);

tree* modificar_arvore(tree* arvore, void** item, tree**sae, tree** sad);

tree* atualizar_item_arvore(tree* arvore, void** item);

tree* atualizar_no_esquerdo(tree* arvore, tree** sae);

tree* atualizar_no_direito(tree* arvore, tree** sad);

tree* atualizar_no(tree* arvore, tree** no, int codigo);

/* Segurança para uso do tipo*/

unsigned avaliar_nulidade_arvore(tree* arvore);

unsigned avaliar_nulidade_item(tree* arvore);

int avaliar_nulidade_filhos(tree* arvore);

/* Operações rotineiras */

void exibir_arvore(tree* arvore);

tree* procurar_arvore(tree* raiz, tree* no);

tree* procurar_item(tree* raiz, void* item, void* (*pegar_item)());

tree* adicionar_no_arvore(tree* raiz, tree* no, int codigo);

tree* remover_no_arvore(tree* raiz, int codigo);

/* Operações varredura */

tree* vasculhar_pre(tree* raiz, void* (*acao_desejada)());

tree* vasculhar_in(tree* raiz, void* (*acao_desejada)());

tree* vasculhar_pos(tree* raiz, void* (*acao_desejada)());

/* Outros métodos */

// numero de folhas

// altura

// numero de ocorrencias de um determinado item


#endif
