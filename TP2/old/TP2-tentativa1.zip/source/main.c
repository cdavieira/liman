#include "tree.h"
#include <stdio.h>
#include <stdlib.h>

void** normal(void**);

int main(int argc, char *argv[]){
    int *n1 = malloc(sizeof(int)), *n2 = malloc(sizeof(int)), *n3 = malloc(sizeof(int));
    *n1 = 1; *n2 = 2; *n3 = 3;
    
    tree* arvore = criar_arvore_alocada_custom((void**)&n1, 0, 0), *arvore2 = criar_arvore_alocada_custom((void**)&n2, 0, 0), *arvore3 = criar_arvore_alocada_custom((void**)&n3, 0, 0);
    atualizar_no_esquerdo(arvore, &arvore2);
    atualizar_no_direito(arvore, &arvore3);
    exibir_arvore(arvore);

    // normal((void**)oi);
    arvore = liberar_arvore_alocada(arvore, (void*)normal);
    arvore2 = liberar_arvore_alocada(arvore2, (void*)normal);
    arvore3 = liberar_arvore_alocada(arvore3, (void*)normal);

    return 0;
}

void** normal(void** ponteiro){
    free(*ponteiro);
    return 0;
}