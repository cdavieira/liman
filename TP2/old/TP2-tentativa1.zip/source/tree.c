#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tree.h"

struct tree{
	void** item;
	tree** sae;
	tree** sad;
};

/* Inicialização e finalização*/

tree* criar_arvore_nula(){
	return 0;
}

tree* criar_arvore_alocada_default(){
	return calloc(1, sizeof(tree));
}

tree* criar_arvore_alocada_custom(void** item, tree** sad, tree** sae){
	tree* arvore = criar_arvore_alocada_default();
	arvore = modificar_arvore(arvore, item, sae, sad);
	return arvore;
}

tree* liberar_arvore_alocada(tree* arvore, void* (*desalocar_item)()){
	desalocar_item(pegar_item_arvore(arvore)); //
	// free(pegar_no_direito(arvore));
	// free(pegar_no_esquerdo(arvore));
	free(arvore);
	return 0;
}

/* Acesso aos campos do tipo estruturado tree*/

void** pegar_item_arvore(tree* arvore){
	return arvore?(*arvore).item:0;
}

tree** pegar_no_esquerdo(tree* arvore){
	return arvore?(*arvore).sae:0;
}

tree** pegar_no_direito(tree* arvore){
	return arvore?(*arvore).sad:0;
}

tree** pegar_no(tree* arvore, int codigo){
	return codigo==left?pegar_no_esquerdo(arvore):pegar_no_direito(arvore);
}

tree* modificar_arvore(tree* arvore, void** item, tree**sae, tree** sad){
	*arvore = (tree){.item = item, .sad = sad, .sae = sae};
	return arvore;
}

tree* atualizar_item_arvore(tree* arvore, void** item){
	(*arvore).item = item;
	return arvore;
}

tree* atualizar_no_esquerdo(tree* arvore, tree** sae){
	(*arvore).sae = sae;
	return arvore;
}

tree* atualizar_no_direito(tree* arvore, tree** sad){
	(*arvore).sad = sad;
	return arvore;
}

tree* atualizar_no(tree* arvore, tree** no, int codigo){
	if(codigo==left) (*arvore).sae = no;
	else (*arvore).sad = no;
	return arvore;
}

/* Segurança para uso do tipo*/

unsigned avaliar_nulidade_arvore(tree* arvore){
	return arvore?0:1;
}

unsigned avaliar_nulidade_item(tree* arvore){
	if(avaliar_nulidade_arvore(arvore)) return 1;
	return pegar_item_arvore(arvore)?0:1;
}

int avaliar_nulidade_filhos(tree* arvore){
	if(avaliar_nulidade_arvore(arvore)) return -1;
	return !pegar_no_direito(arvore) && !pegar_no_esquerdo(arvore)?1:0;
}

/* Operações rotineiras */

//precisa passar a funcao que exibe o conteudo
void exibir_arvore(tree* arvore){
	printf("<%d", **(int**)pegar_item_arvore(arvore));
	if((*arvore).sae) exibir_arvore(*((*arvore).sae)); 
	if((*arvore).sad) exibir_arvore(*((*arvore).sad)); 
	printf(">");
}

tree* procurar_arvore(tree* raiz, tree* no);

tree* procurar_item(tree* raiz, void* item, void* (*pegar_item)());

tree* adicionar_no_arvore(tree* raiz, tree* no, int codigo);

tree* remover_no_arvore(tree* raiz, int codigo);

/* Operações varredura */

tree* vasculhar_pre(tree* raiz, void* (*acao_desejada)());

tree* vasculhar_in(tree* raiz, void* (*acao_desejada)());

tree* vasculhar_pos(tree* raiz, void* (*acao_desejada)());
